Assignment 6 : USB Keyboard Driver

Instructions on how the module will be tested:

1) Compile : $make

2) Load module : $sudo insmod usbkbd.ko

3) $sudo ./usbKeyboard.sh

4) Unload module : $sudo rmmod usbkbd
